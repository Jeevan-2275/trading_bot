# Binance Futures Testnet Trading Bot

A high-fidelity Python application to place and validate orders on the **Binance Futures Testnet (USDT-M)**. It features parameter validations, network time drift correction, dual console/file logging, and a premium interactive user interface.

---

## Features

1. **Order Types**: Supports `MARKET`, `LIMIT`, and `STOP_MARKET` order types.
2. **Dual-Mode CLI**:
   - **Direct Argument Mode**: Pass parameters directly via terminal command line flags.
   - **Interactive Menu Mode**: Run the script without arguments to open a guided, validated menu with step-by-step prompts.
3. **Advanced Client Capabilities**:
   - Automatic HMAC-SHA256 signature signing using your API secret.
   - **Server Time Synchronization**: Automatically queries the Binance server time to calculate and adjust for local time drift, completely avoiding the common `-1021: Timestamp for this request is outside of the recvWindow` error.
   - **Dry Run Flag (`--test`)**: Validates parameters and signatures against the Binance Testnet endpoint `/fapi/v1/order/test` without executing actual trades.
4. **Structured & Resilient Logging**:
   - Captures detailed API request query strings, response status, payloads, and validation details in `trading_bot.log`.
   - Rich console outputs with visual styling (colored tags, response tables, and progress indications).
5. **Robust Local Validation**: Validates symbol formats, positive quantities, sides, and prices before hitting the network to save API quotas and avoid unnecessary errors.

---

## Project Structure

```text
trading_bot/
│
├── bot/
│   ├── __init__.py          # Package initialization
│   ├── client.py            # Binance client wrapper, signatures, time sync
│   ├── orders.py            # Higher-level order orchestration layer
│   ├── validators.py        # Symbol, side, price, quantity validators
│   └── logging_config.py    # Console (rich/standard) & file logger setup
│
├── .env.example             # Template file for API credentials
├── cli.py                   # Main CLI Entrypoint (Direct + Interactive)
├── requirements.txt         # Project dependencies
└── test_bot.py              # Suite of unit tests
```

---

## Setup Instructions

### 1. Prerequisites
- Python 3.8 or higher (Tested on Python 3.11)

### 2. Install Dependencies
You can install the required dependencies (such as `requests` and `rich` for formatting) via pip:
```bash
pip install -r requirements.txt
```

### 3. API Credentials
1. Register and log in to the [Binance Futures Testnet](https://testnet.binancefuture.com) (using Google/GitHub).
2. Generate API credentials under your profile dashboard.
3. Copy the `.env.example` file to `.env`:
   ```bash
   cp .env.example .env
   ```
4. Edit the `.env` file and insert your API Key and Secret:
   ```env
   BINANCE_API_KEY=your_actual_testnet_api_key
   BINANCE_API_SECRET=your_actual_testnet_api_secret
   ```

---

## How to Run Examples

### 1. Direct Command Mode (with CLI Arguments)

You can place orders by passing arguments directly:

*   **Place a Dry-Run MARKET BUY Order (no risk)**:
    ```bash
    python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01 --test
    ```
*   **Place a Real LIMIT SELL Order**:
    ```bash
    python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 60000
    ```
*   **Place a Dry-Run STOP_MARKET SELL Order**:
    ```bash
    python cli.py --symbol BTCUSDT --side SELL --type STOP_MARKET --quantity 0.01 --stop-price 55000 --test
    ```

### 2. Interactive Wizard Mode

If you run the script without any parameters, it automatically opens the Interactive Wizard:
```bash
python cli.py
```
This is fully validated, offering color-coded guidance and error messages if you insert an invalid symbol or positive float, ensuring a smooth experience.

---

## Running Unit Tests

The test suite validates input parsing, signing algorithms, and mocks responses from the Binance API. You can run all tests using:
```bash
python -m unittest test_bot.py
```

---

## Design Assumptions & Decisions

1. **Time Offset Correction**: Binance requests expire if the local timestamp is not within a few seconds of the server's. We request server time once during initialization to balance timestamps and avoid errors when the host clock is slightly off.
2. **Form Encoded Request Body**: Parameters are encoded as `application/x-www-form-urlencoded` and sent in the body of the `POST` request, conforming to standard REST security practices.
3. **Graceful Dependency Fallbacks**: If `rich` or `python-dotenv` are missing from the system and dependencies cannot be installed, the application falls back gracefully to standard `print` statements, ANSI color codes, and a manual `.env` reader, ensuring the program runs out-of-the-box.
