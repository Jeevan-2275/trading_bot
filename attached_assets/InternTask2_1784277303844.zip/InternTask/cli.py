import os
import sys
import argparse
from typing import Tuple, Optional, Any

# Ensure current directory is in PYTHONPATH
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

from bot.logging_config import setup_logging, logger
from bot.validators import (
    validate_symbol,
    validate_side,
    validate_order_type,
    validate_quantity,
    validate_price,
    validate_stop_price
)
from bot.orders import execute_order

# Load environment variables
def load_env() -> None:
    """
    Attempts to load environment variables from a .env file.
    Uses python-dotenv if installed, otherwise uses a basic custom parser.
    """
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        # Fallback manual parser for .env to avoid dependency bottlenecks
        if os.path.exists(".env"):
            with open(".env", "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        os.environ[k.strip()] = v.strip()

# Print formatting helpers
def print_success(text: str) -> None:
    try:
        from rich.console import Console
        Console().print(f"[bold green]SUCCESS:[/bold green] {text}")
    except ImportError:
        print(f"\033[92mSUCCESS: {text}\033[0m" if os.name == 'nt' or sys.stdout.isatty() else f"SUCCESS: {text}")

def print_error(text: str) -> None:
    try:
        from rich.console import Console
        Console().print(f"[bold red]ERROR:[/bold red] {text}")
    except ImportError:
        print(f"\033[91mERROR: {text}\033[0m" if os.name == 'nt' or sys.stdout.isatty() else f"ERROR: {text}")

def print_info(text: str) -> None:
    try:
        from rich.console import Console
        Console().print(f"[bold yellow]INFO:[/bold yellow] {text}")
    except ImportError:
        print(f"\033[93mINFO: {text}\033[0m" if os.name == 'nt' or sys.stdout.isatty() else f"INFO: {text}")

def print_table(title: str, data: dict) -> None:
    """
    Renders key-value data nicely in a terminal table.
    """
    try:
        from rich.table import Table
        from rich.console import Console
        table = Table(title=title, show_header=True, header_style="bold magenta")
        table.add_column("Field", style="cyan")
        table.add_column("Value", style="green")
        for k, v in data.items():
            table.add_row(str(k), str(v))
        Console().print(table)
    except ImportError:
        print(f"\n=== {title} ===")
        for k, v in data.items():
            print(f"{k}: {v}")
        print("=" * (len(title) + 8) + "\n")

# Interactive prompting helpers
def prompt_input(prompt_text: str, validator: Any = None) -> str:
    """
    Prompts the user for text input and re-runs on failure if a validator is supplied.
    """
    while True:
        try:
            val = input(prompt_text).strip()
            if validator:
                return validator(val)
            return val
        except ValueError as e:
            print_error(str(e))

def prompt_choice(prompt_text: str, choices: list) -> str:
    """
    Prompts the user to select from a list of choices.
    """
    choices_str = "/".join(choices)
    while True:
        val = input(f"{prompt_text} ({choices_str}): ").strip().upper()
        if val in choices:
            return val
        print_error(f"Invalid selection. Please enter one of: {choices}")

def run_interactive() -> Tuple[str, str, str, float, Optional[float], Optional[float], bool]:
    """
    Runs the guided interactive CLI prompt to gather order requirements.
    """
    try:
        from rich.console import Console
        from rich.panel import Panel
        Console().print(Panel.fit(
            "[bold cyan]Binance Futures Order Placement Wizard[/bold cyan]\n"
            "This wizard will guide you through placing a test order.",
            border_style="magenta"
        ))
    except ImportError:
        print("\n=== Binance Futures Order Placement Wizard ===\n")
        
    symbol = prompt_input("Enter Symbol (e.g. BTCUSDT, ETHUSDT): ", validate_symbol)
    side = prompt_choice("Select Side", ["BUY", "SELL"])
    order_type = prompt_choice("Select Order Type", ["MARKET", "LIMIT", "STOP_MARKET"])
    
    quantity = prompt_input("Enter Quantity: ", validate_quantity)
    
    price = None
    if order_type == "LIMIT":
        price = prompt_input("Enter Limit Price: ", lambda x: validate_price(x, order_type))
        
    stop_price = None
    if order_type == "STOP_MARKET":
        stop_price = prompt_input("Enter Stop Price: ", lambda x: validate_stop_price(x, order_type))
        
    test_mode_choice = prompt_choice("Place Dry-Run Order? (Validates settings without trading)", ["YES", "NO"])
    test_mode = (test_mode_choice == "YES")
    
    return symbol, side, order_type, quantity, price, stop_price, test_mode

def main() -> None:
    # Setup logger
    setup_logging()
    
    # Load env variables from .env
    load_env()
    
    # Retrieve credentials
    api_key = os.environ.get("BINANCE_API_KEY", "")
    api_secret = os.environ.get("BINANCE_API_SECRET", "")
    
    # Setup CLI arg parser
    parser = argparse.ArgumentParser(
        description="Place Market, Limit, and Stop Market orders on Binance Futures Testnet."
    )
    parser.add_argument("--symbol", help="Trading pair, e.g., BTCUSDT")
    parser.add_argument("--side", choices=["BUY", "SELL"], help="Order side")
    parser.add_argument("--type", choices=["MARKET", "LIMIT", "STOP_MARKET"], help="Order type")
    parser.add_argument("--quantity", type=float, help="Order quantity")
    parser.add_argument("--price", type=float, help="Limit price (required for LIMIT orders)")
    parser.add_argument("--stop-price", type=float, help="Stop price (required for STOP_MARKET orders)")
    parser.add_argument("--test", action="store_true", help="Submit to validation endpoint (Dry Run)")
    parser.add_argument("--interactive", action="store_true", help="Force interactive prompt mode")
    
    args = parser.parse_args()
    
    # Decide between Interactive and Direct mode
    # If no parameters are provided (or --interactive is set), we run in interactive mode.
    if args.interactive or (not args.symbol and not args.side and not args.type and args.quantity is None):
        symbol, side, order_type, quantity, price, stop_price, test_mode = run_interactive()
    else:
        # Direct command line argument mode
        symbol = args.symbol
        side = args.side
        order_type = args.type
        quantity = args.quantity
        price = args.price
        stop_price = args.stop_price
        test_mode = args.test
        
    # Render Request Summary
    summary_data = {
        "Symbol": symbol,
        "Side": side,
        "Order Type": order_type,
        "Quantity": quantity,
        "Price": price if price is not None else "N/A",
        "Stop Price": stop_price if stop_price is not None else "N/A",
        "Dry Run (Test Mode)": "Yes" if test_mode else "No"
    }
    print_table("Order Request Details", summary_data)
    
    # Validate API key exists
    if not api_key or not api_secret:
        print_info(
            "API Credentials not found in environment.\n"
            "You can enter them below or configure a .env file to skip this step."
        )
        api_key = input("Enter Binance Futures Testnet API Key: ").strip()
        api_secret = input("Enter Binance Futures Testnet API Secret: ").strip()
        
    # Execute the order
    result = execute_order(
        api_key=api_key,
        api_secret=api_secret,
        symbol=symbol,
        side=side,
        order_type=order_type,
        quantity=quantity,
        price=price,
        stop_price=stop_price,
        test_mode=test_mode
    )
    
    # Print results
    if result["success"]:
        if result.get("test_mode"):
            print_success(result["message"])
        else:
            print_success(f"Order executed successfully on Testnet!")
            response_summary = {
                "OrderID": result.get("order_id"),
                "Status": result.get("status"),
                "Executed Qty": result.get("executed_qty"),
                "Average Price": result.get("avg_price")
            }
            print_table("Response Summary", response_summary)
    else:
        print_error(result["message"])
        if "data" in result:
            print_table("Error Payload", result["data"])
            
if __name__ == "__main__":
    main()
